# nn-faceswap
CIS 581: Computer Vision final project

Deniz Beser
Mia Chiquier
John Wallison

We used the following packages:
- cv2
- face_recognition

A demo script (demo.py) is provided, as well as all the code required to generate the face-swapping videos.

We have also included our experimentation with autoencoders in this submission. To run those files, Keras and Tensorflow must be installed. This was not an original part of our pipeline, so the demo script will not use this code.
